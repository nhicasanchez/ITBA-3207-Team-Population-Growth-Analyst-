<?php
	include 'includes/session.php';
	
	function generateRow($conn){
		$contents = '';
	 	$id = $_GET['id'];
		$sql = "SELECT * FROM records WHERE ID = '$id'";
        $query = $conn->query($sql);
        while($row = $query->fetch_assoc()){
        	$id = $row['ID'];
			$applicant_first_checkup = "";
			$applicant_second_checkup = "";
			$applicant_third_checkup = "";
			
			$doctor_first_checkup = "";
			$doctor_second_checkup = "";
			$doctor_third_checkup = "";
			
			// applicant
			if($row['applicant_first_checkup'] == "0"){
				$applicant_first_checkup = $row['date_first_checkup'];
			}
			else if($row['applicant_first_checkup'] == "2"){
				$applicant_first_checkup = "Not Attended";
			}
			else{
				$applicant_first_checkup = "Attended";
			}
			
			if($row['applicant_second_checkup'] == "0"){
				$applicant_second_checkup = $row['date_second_checkup'];
			}
			else if($row['applicant_second_checkup'] == "2"){
				$applicant_second_checkup = "Not Attended";
			}
			else{
				$applicant_second_checkup = "Attended";
			}
			
			if($row['applicant_third_checkup'] == "0"){
				$applicant_third_checkup = $row['date_third_checkup'];
			}
			else if($row['applicant_third_checkup'] == "2"){
				$applicant_third_checkup = "Not Attended";
			}
			else{
				$applicant_third_checkup = "Attended";
			}
			
			//doctor
			
			if($row['doctor_first_checkup'] == "0"){
				$doctor_first_checkup = $row['date_first_checkup'];
			}
			else if($row['doctor_first_checkup'] == "2"){
				$doctor_first_checkup = "Not Attended";
			}
			else{
				$doctor_first_checkup = "Attended";
			}
			
			if($row['doctor_second_checkup'] == "0"){
				$doctor_second_checkup = $row['date_second_checkup'];
			}
			else if($row['doctor_second_checkup'] == "2"){
				$doctor_second_checkup = "Not Attended";
			}
			else{
				$doctor_second_checkup = "Attended";
			}
			
			if($row['doctor_third_checkup'] == "0"){
				$doctor_third_checkup = $row['date_third_checkup'];
			}
			else if($row['doctor_third_checkup'] == "2"){
				$doctor_third_checkup = "Not Attended";
			}
			else{
				$doctor_third_checkup = "Attended";
			}
			
			
        	$contents .= '
			<h1 align="center">  </h1>
			<table border="1" cellspacing="0" cellpadding="3"> 
			<tr>
			<td colspan="2" align="center" style="font-size:10px;"><b>APPOINTMENT</b></td>
			<td colspan="2" align="center" style="font-size:10px;"><b>SUBJECT</b></td>
			<td colspan="2" align="center" style="font-size:10px;"><b>DESCRIPTION</b></td>
			<td colspan="2" align="center" style="font-size:10px;"><b>DATE AND TIME</b></td>
			<td colspan="2" align="center" style="font-size:10px;"><b>STATUS</b></td>
			</tr>
			<tr>
			<td align="center" width="20%"><b>'.$id.'</b></td>
			<td align="center" width="20%"><b>'.$row['subject'].'</b></td>
			<td align="center" width="20%"><b>'.$row['description'].'</b></td>
			<td align="center" width="20%"><b>'.$row['datetime'].'</b></td>
			<td align="center" width="20%"><b>'.$row['status'].'</b></td>
			</tr>
			<hr>
			</table>
			<h1 align="center">  </h1>
			<table border="1" cellspacing="0" cellpadding="3">
			
			<tr>
			<td colspan="2" align="center" style="font-size:10px;"><b>APPLICANT</b></td>
			<td colspan="2" align="center" style="font-size:10px;"><b>AGE</b></td>
			<td colspan="2" align="center" style="font-size:10px;"><b>GENDER</b></td>
			<td colspan="2" align="center" style="font-size:10px;"><b>ADDRESS</b></td>
			<td colspan="2" align="center" style="font-size:10px;"><b>CONTACT</b></td>
			</tr>
			<tr>
			<td align="center" width="20%"><b>'.$row['cfirstname']. " " .$row['cmiddlename']. " " .$row['clastname'].'</b></td>
			<td align="center" width="20%"><b>'.$row['cage'].'</b></td>
			<td align="center" width="20%"><b>'.$row['cgender'].'</b></td>
			<td align="center" width="20%"><b>'.$row['caddress'].'</b></td>
			<td align="center" width="20%"><b>'.$row['cphone'].'</b></td>
			</tr>
			<hr>
			</table>
			
			<h1 align="center">  </h1>
			<table border="1" cellspacing="0" cellpadding="3">
			
			<tr>
			<td colspan="2" align="center" style="font-size:10px;"><b>DOCTOR</b></td>
			<td colspan="2" align="center" style="font-size:10px;"><b>AGE</b></td>
			<td colspan="2" align="center" style="font-size:10px;"><b>GENDER</b></td>
			<td colspan="2" align="center" style="font-size:10px;"><b>ADDRESS</b></td>
			<td colspan="2" align="center" style="font-size:10px;"><b>CONTACT</b></td>
			</tr>
			<tr>
			<td align="center" width="20%"><b>'.$row['afirstname']. " " .$row['amiddlename']. " " .$row['alastname'].'</b></td>
			<td align="center" width="20%"><b>'.$row['aage'].'</b></td>
			<td align="center" width="20%"><b>'.$row['agender'].'</b></td>
			<td align="center" width="20%"><b>'.$row['aaddress'].'</b></td>
			<td align="center" width="20%"><b>'.$row['aphone'].'</b></td>
			</tr>
			<hr>
			</table>
			
			
			<h1 align="center">  </h1>
			<table border="1" cellspacing="0" cellpadding="3">
			
			<tr>
			<td colspan="2" align="center" style="font-size:10px;"><b>ATTENDANCE</b></td>
			<td colspan="2" align="center" style="font-size:10px;"><b>FIRST CHECKUP</b></td>
			<td colspan="2" align="center" style="font-size:10px;"><b>SECOND CHECKUP</b></td>
			<td colspan="2" align="center" style="font-size:10px;"><b>THIRD CHECKUP</b></td>
			</tr>
			<tr>
			<td align="center" width="25%" style="font-size:10px;"><b>APPLICANT</b></td>
			<td align="center" width="25%"><b>'.$applicant_first_checkup.'</b></td>
			<td align="center" width="25%"><b>'.$applicant_second_checkup.'</b></td>
			<td align="center" width="25%"><b>'.$applicant_third_checkup.'</b></td>
			
			</tr>
			<tr>
			<td align="center" width="25%" style="font-size:10px;"><b>DOCTOR</b></td>
			<td align="center" width="25%"><b>'.$doctor_first_checkup.'</b></td>
			<td align="center" width="25%"><b>'.$doctor_second_checkup.'</b></td>
			<td align="center" width="25%"><b>'.$doctor_third_checkup.'</b></td>
			
			</tr>
			
			</table>
			
			
        	';
			
        	
			
		}
		
		return $contents;
	}
	
	
	require_once('tcpdf/tcpdf.php');  
	
	class MYPDF extends TCPDF {
		
		//Page header
		public function Header() {
			// Logo
			
			$image_file = "PREAPP.JPG";
			$this->Image($image_file, 0, 10, 15, '', 'JPG', '', 'T', false, 300, 'R', false, false, 0, false, false, false);
			// Set font
			$this->SetFont('diploma', 'B', 12);
			// Title
			$this->SetXY(15, 15);
		$this->Cell(0, 0, 'Batangas City', 0, false, 'L', 0, '', 0, false, 'B', 'C');
		
		$this->SetFont('helvetica', 'B', 15);
		$this->SetXY(15, 21);
		$this->Cell(0, 0, 'Batangas Medical Center', 0, false, 'L', 0, '', 0, false, 'B', 'C');
		
		$this->SetFont('helvetica', 'B', 10);
		$this->SetXY(15, 25);
		$this->Cell(0, 0, 'Batangas City', 0, false, 'L', 0, '', 0, false, 'B', 'C');
		
		
		
		
		}
		
		// Page footer
		public function Footer() {
		
		$this->SetXY(30, 279);
		$this->Cell(0, 0, 'Sulong sa Pagbabago', 0, false, 'C', 0, '', 0, false, 'B', 'C');
		$this->SetXY(30, 283);
		$this->Cell(0, 0, 'Email Address: batangas.123.123@gmail.com', 0, false, 'C', 0, '', 0, false, 'B', 'C');
		$this->SetXY(30, 287);
		$this->Cell(0, 0, 'Telephone #: 8-999-32-00/ 8-520-10-01', 0, false, 'C', 0, '', 0, false, 'B', 'C');
        
		}
		}
		$pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
		
		//$pdf = new TCPDF('P', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);  
		$pdf->SetCreator(PDF_CREATOR);  
		$pdf->SetTitle("Print");  
		$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE, PDF_HEADER_STRING);
		
		//$pdf->SetHeaderData('', '', PDF_HEADER_TITLE, PDF_HEADER_STRING);  
		$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));  
		$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));  
		$pdf->SetDefaultMonospacedFont('helvetica');  
		$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);  
		$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);  
		//$pdf->setPrintHeader(false);  
		//$pdf->setPrintFooter(false);  
		$pdf->SetAutoPageBreak(TRUE, 10);  
		$pdf->SetFont('helvetica', '', 11);  
		$pdf->AddPage(); 
		
		$pdf->writeHTML(generateRow($conn));  
		$pdf->Output('appointment.pdf', 'I');
		
		?>		