<?php
	include 'includes/session.php';
	
	if(isset($_POST['edit'])){
		
		$record_id = $_POST['record_id'];
		$password = $_POST['copassword'];
		$sql = "SELECT * FROM records WHERE ID='$record_id'";
        $query = $conn->query($sql);
		$row = $query->fetch_assoc();
		
		if(password_verify($password, $row['cpassword'])){
			$_SESSION['success'] = 'Password matched';
			header('location: editrecord.php?record_id='.$record_id);
		}
		else{
			$_SESSION['error'] = 'Incorrect Password'. $conn->error;
			header('location: records.php');
		}
		
	}
	else{
		$_SESSION['error'] = 'Fill up edit form first';
		header('location: records.php');
	}
	
	//header('location: users.php');
	
?>