<?php
	include 'includes/session.php';
	
	if(isset($_POST['delete'])){
		$delete_coid = $_POST['delete_coid'];
		$password = $_POST['delete_co_password'];
		echo $delete_coid;
		echo $password;
		
		$sql = "SELECT * FROM records WHERE ID ='$delete_coid'";                     
		$query = $conn->query($sql);
		$row = $query->fetch_assoc();
		
		echo $row['cpassword'];
		if(password_verify($password, $row['cpassword'])){	
			$sql = "DELETE FROM records WHERE ID = '$delete_coid'";
			if($conn->query($sql)){
				$_SESSION['success'] = 'Record deleted successfully';
			}
			else{
				$_SESSION['error'] = $conn->error;
				
			}
		}
		else{
			$_SESSION['error'] = 'Incorrect Complainant Password'. $conn->error;
			echo "Incorrect:".$conn->error;
			header('location: records.php');
		}
		
		
		
		
		
	}
	else{
		$_SESSION['error'] = 'Select item to delete first';
	}
	
	header('location: records.php');
	
?>