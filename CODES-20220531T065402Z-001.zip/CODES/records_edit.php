<?php
	include 'includes/session.php';

	if(isset($_POST['edit'])){
		
		$record_id = $_POST['id'];
		$datetime = $_POST['datetime'];
		$subject = $_POST['subject'];
		$description = $_POST['description'];
		
		
		$cfirstname = $_POST['cfirstname'];
		$cmiddlename = $_POST['cmiddlename'];
		$clastname = $_POST['clastname'];
		$cage = $_POST['cage'];
		$cresidence = $_POST['cresidence1'];
		$cpurok = $_POST['cpurok'];
		$caddress = $_POST['caddress'];
		$cgender = $_POST['cgender'];
		$cphone = $_POST['cphone'];
		$cemail = $_POST['cemail'];
		
		$cfirstname = strtolower($cfirstname);
		$cmiddlename = strtolower($cmiddlename);
		$clastname = strtolower($clastname);
		
		$cfirstname = ucwords($cfirstname);
		$cmiddlename = ucwords($cmiddlename);
		$clastname = ucwords($clastname);
		
		$afirstname = $_POST['afirstname'];
		$amiddlename = $_POST['amiddlename'];
		$alastname = $_POST['alastname'];
		$aage = $_POST['aage'];
		$aresidence = $_POST['aresidence1'];
		$apurok = $_POST['apurok'];
		$aaddress = $_POST['aaddress'];
		$agender = $_POST['agender'];
		$aphone = $_POST['aphone'];
		$aemail = $_POST['aemail'];
		
		$afirstname = strtolower($afirstname);
		$amiddlename = strtolower($amiddlename);
		$alastname = strtolower($alastname);
		
		$afirstname = ucwords($afirstname);
		$amiddlename = ucwords($amiddlename);
		$alastname = ucwords($alastname);
		
		$sql = "UPDATE `records` SET `subject`='$subject',`description`='$description',
		`cfirstname`='$cfirstname',`cmiddlename`='$cmiddlename',`clastname`='$clastname',`cage`='$cage',
		`cgender`='$cgender',`cresidence`='$cresidence',`cpurok`='$cpurok',`caddress`='$caddress',`cphone`='$cphone',`cemail`='$cemail',
		`afirstname`='$afirstname',`amiddlename`='$amiddlename',
		`alastname`='$alastname',`aage`='$aage',`agender`='$agender',`aresidence`='$aresidence',`apurok`='$apurok',`aaddress`='$aaddress',
		`aphone`='$aphone',`aemail`='$aemail',`aphoto`='$aphoto',`datetime`='$datetime' WHERE ID = '$record_id'";
			if($conn->query($sql)){
			$_SESSION['success'] = 'Record updated successfully';
			}
			else{
			$_SESSION['error'] = $conn->error;
			}		
	}
	else{
		$_SESSION['error'] = 'Fill up edit form first';
	}

	header('location: records.php');

?>