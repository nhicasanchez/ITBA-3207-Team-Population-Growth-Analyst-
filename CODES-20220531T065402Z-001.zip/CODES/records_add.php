<?php
	include 'includes/session.php';
	date_default_timezone_set('Asia/Manila');
	if(isset($_POST['add'])){
		
		$record_id = $_POST['id'];
		
		$subject = $_POST['subject'];
		$description = $_POST['description'];
		$datetime = $_POST['datetime'];
		
		$cfirstname = $_POST['cfirstname'];
		$cmiddlename = $_POST['cmiddlename'];
		$clastname = $_POST['clastname'];
		$cage = $_POST['cage'];
		$cresidence = $_POST['cresidence'];
		$cpurok = $_POST['cpurok'];
		$caddress = $_POST['caddress'];
		$cgender = $_POST['cgender'];
		$cphone = $_POST['cphone'];
		$cemail = $_POST['cemail'];
		$cfilename = $_FILES['cphoto']['name'];
		
		
		$cfirstname = strtolower($cfirstname);
		$cmiddlename = strtolower($cmiddlename);
		$clastname = strtolower($clastname);
		
		$cfirstname = ucwords($cfirstname);
		$cmiddlename = ucwords($cmiddlename);
		$clastname = ucwords($clastname);
		
		$afirstname = $_POST['afirstname'];
		$amiddlename = $_POST['amiddlename'];
		$alastname = $_POST['alastname'];
		$aage = $_POST['aage'];
		$aresidence = $_POST['aresidence'];
		$apurok = $_POST['apurok'];
		$aaddress = $_POST['aaddress'];
		$agender = $_POST['agender'];
		$aphone = $_POST['aphone'];
		$aemail = $_POST['aemail'];
		$afilename = $_FILES['aphoto']['name'];
		
		$afirstname = strtolower($afirstname);
		$amiddlename = strtolower($amiddlename);
		$alastname = strtolower($alastname);
		
		$afirstname = ucwords($afirstname);
		$amiddlename = ucwords($amiddlename);
		$alastname = ucwords($alastname);
		
		$author = $user['firstname'] . " " . $user['lastname'];
		
		
			$cpassword = password_hash($_POST['cpassword'], PASSWORD_DEFAULT);
			
			
			
			if(!empty($cfilename)){
				
				move_uploaded_file($_FILES['cphoto']['tmp_name'], '../images/'.$cfilename);
				
			}
			
			if(!empty($afilename)){
				
				move_uploaded_file($_FILES['aphoto']['tmp_name'], '../images/'.$afilename);
				
			}
			$Date = date('Y-m-d');
			
			
			$date_first_hearing = date('Y-m-d', strtotime($Date. ' + 3 days'));
			if(strtolower(date("l", strtotime($date_first_hearing))) == "saturday" || strtolower(date("l", strtotime($date_first_hearing))) == "sunday"){
				
				if(strtolower(date("l", strtotime($date_first_hearing))) == "saturday"){
					$date_first_hearing = date('Y-m-d', strtotime($date_first_hearing. ' + 2 days'));
				}
				else if(strtolower(date("l", strtotime($date_first_hearing))) == "sunday"){
					$date_first_hearing = date('Y-m-d', strtotime($date_first_hearing. ' + 1 days'));
				}
				
			}
			$date_second_hearing = date('Y-m-d', strtotime($date_first_hearing. ' + 7 days'));
			
			
			if(strtolower(date("l", strtotime($date_second_hearing))) == "saturday" || strtolower(date("l", strtotime($date_second_hearing))) == "sunday"){
				
				if(strtolower(date("l", strtotime($date_second_hearing))) == "saturday"){
					$date_second_hearing = date('Y-m-d', strtotime($date_second_hearing. ' + 2 days'));
				}
				else if(strtolower(date("l", strtotime($date_second_hearing))) == "sunday"){
					$date_second_hearing = date('Y-m-d', strtotime($date_second_hearing. ' + 1 days'));
				}
				
			}
			
			$date_third_hearing = date('Y-m-d', strtotime($date_second_hearing. ' + 7 days'));
			
			if(strtolower(date("l", strtotime($date_third_hearing))) == "saturday" || strtolower(date("l", strtotime($date_third_hearing))) == "sunday"){
				
				if(strtolower(date("l", strtotime($date_third_hearing))) == "saturday"){
					$date_third_hearing = date('Y-m-d', strtotime($date_third_hearing. ' + 2 days'));
				}
				else if(strtolower(date("l", strtotime($date_third_hearing))) == "sunday"){
					$date_third_hearing = date('Y-m-d', strtotime($date_third_hearing. ' + 1 days'));
				}
				
			}
			
			
			$sql = "INSERT INTO `records`(`ID`,`subject`, `description`, `cfirstname`, `cmiddlename`, `clastname`, `cage`, `cgender`, `cresidence`, `cpurok`, `caddress`, 
			`cphone`, `cemail`, `cphoto`, `cpassword`, `afirstname`, `amiddlename`, `alastname`, `aage`, `agender`, `aresidence`, `apurok`, `aaddress`, `aphone`, `aemail`, `aphoto`, `status`, 
			`date_first_hearing`, `status_first_hearing`, `date_second_hearing`, `status_second_hearing`, `date_third_hearing`, `status_third_hearing`, 
			`datetime`, `date_created`,`author`, `complainant_first_hearing`,`complainant_second_hearing`,`complainant_third_hearing`,`accused_first_hearing`, 
			`accused_second_hearing`,`accused_third_hearing`) 
			VALUES ('$record_id','$subject','$description','$cfirstname','$cmiddlename','$clastname','$cage','$cgender','$cresidence','$cpurok','$caddress',
			'$cphone','$cemail','$cfilename', '$cpassword','$afirstname','$amiddlename','$alastname','$aage','$agender','$aresidence','$apurok','$aaddress','$aphone','$aemail',
			'$afilename','ACTIVE','$date_first_hearing','1','$date_second_hearing','1','$date_third_hearing', '1', now(), now(), '$author', 0,0,0,0,0,0)";
			
			if($conn->query($sql)){
				$_SESSION['success'] = 'Record added successfully';
			}
			else{
				$_SESSION['error'] = $conn->error;
			}
			
		}
		
	else{
		$_SESSION['error'] = 'Fill up add form first';
	}
	
	function isWeekend($date) {
		return (date('N', strtotime($date)) >= 6);
	}
	
	header('location: records.php');
?>